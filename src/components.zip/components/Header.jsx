import React from "react";

const Header = () => {
	return <h1 style={{ color: "#eee" }}>My tasks</h1>;
};

export default Header;
